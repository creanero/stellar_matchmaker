# Stellar Matchmaker
This is a software package to match input targets to reference stars for differential photometry in Exoplanet transit observations

# # Placeholder instructions
From the root directory of this repository, run the following command:

*python stellar_matchmaker/stellar_matchmaker.py*
