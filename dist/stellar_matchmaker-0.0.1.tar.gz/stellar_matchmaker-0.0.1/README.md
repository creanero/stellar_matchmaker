# Stellar Matchmaker
This is a software package to match input targets to reference stars for differential photometry in Exoplanet transit observations
